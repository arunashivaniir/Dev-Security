const { body } = require("express-validator");

exports.createUserValidator = [
  body("name").isString().notEmpty(),
  body("email").isEmail()
];

exports.updateUserValidator = [
  body("name").optional().isString(),
  body("email").optional().isEmail(),
];
const createUserValidator = [
  body("name").isString().notEmpty(),
  body("email").isEmail()
];

const updateUserValidator = [
  body("name").optional().isString(),
  body("email").optional().isEmail()
];

module.exports = { createUserValidator, updateUserValidator };
