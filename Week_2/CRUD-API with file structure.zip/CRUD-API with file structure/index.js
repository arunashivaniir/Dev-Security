const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cors = require("cors");
const sanitizeBody = require("./middleware/sanitize");
const logger = require("./middleware/logger");
const usersRoute = require("./routes/users");

const app = express();


// ---------- GLOBAL MIDDLEWARES ----------
app.use(express.json());
app.use(helmet());

// Rate limiter
app.use(
  rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 20,
    message: { msg: "Too many requests, slow down." }
  })
);

// CORS
app.use(
  cors({
    origin: ["http://localhost:3001"],
    methods: ["GET", "POST", "PUT", "DELETE"]
  })
);

// Trim inputs
app.use((req, res, next) => {
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === "string") {
        req.body[key] = req.body[key].trim();
      }
    }
  }
  next();
});

// Sanitize HTML
app.use(sanitizeBody);

// Logger
app.use(logger);


// ---------- ROUTES ----------
app.use("/users", usersRoute);


// ---------- 404 ----------
app.use((req, res) => {
  res.status(404).json({ msg: "Route not found" });
});


// ---------- ERROR HANDLER ----------
app.use((err, req, res, next) => {
  console.error("ERROR:", err.stack || err.message);
  res.status(500).json({ msg: "Internal Server Error" });
});


// ---------- START ----------
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
