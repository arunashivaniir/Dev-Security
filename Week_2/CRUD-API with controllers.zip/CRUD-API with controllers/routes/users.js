const express = require("express");
const router = express.Router();
const { validationResult } = require("express-validator");
const { createUserValidator, updateUserValidator } = require("../utils/validation");
const { createUser, getUser, updateUser, deleteUser } = require("../controllers/users.controller");
const { getAllUsers } = require("../controllers/users.controller");

// READ ALL
router.get("/", getAllUsers);

// CREATE
router.post("/", createUserValidator, createUser);

// READ ONE
router.get("/:id", getUser);

// UPDATE
router.put("/:id", updateUserValidator, updateUser);

// DELETE
router.delete("/:id", deleteUser);

module.exports = router;

