const express = require("express");
const app = express();

app.use(express.json());

app.get("/", (req, res) => {
  res.json({ message: "Server is running!" });
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});

app.get("/hello", (req, res) => {
  res.json({ msg: "Hello from the API" });
});

app.post("/echo", (req, res) => {
  res.json({ received: req.body });
});

const { body, validationResult } = require("express-validator");

app.post(
  "/register",
  [
    body("email").isEmail(),
    body("password").isLength({ min: 6 })
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    res.json({ msg: "Registration data is valid" });
  }
);
