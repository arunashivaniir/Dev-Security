let users = [];
let id = 1;

const express = require("express");
const { body, validationResult } = require("express-validator");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cors = require("cors");
const sanitizeHtml = require("sanitize-html");
const app = express();


// ---------- MIDDLEWARE ----------
app.use(express.json());
app.use(helmet());


app.use(
  rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 20,
    message: { msg: "Too many requests, slow down." }
  })
);

app.use(
  cors({
    origin: ["http://localhost:3001"],
    methods: ["GET", "POST", "PUT", "DELETE"]
  })
);

// Trim all incoming strings
app.use((req, res, next) => {
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === "string") {
        req.body[key] = req.body[key].trim();
      }
    }
  }
  next();
});

app.use((req, res, next) => {
  if (req.body) {
    for (const key in req.body) {
      if (typeof req.body[key] === "string") {
        req.body[key] = sanitizeHtml(req.body[key]);
      }
    }
  }
  next();
});


// Logging
app.use((req, res, next) => {
  console.log(
    `[${new Date().toISOString()}] ${req.method} ${req.url} | body: `,
    req.body
  );
  next();
});

// ---------- ROUTES ----------

// CREATE user
app.post(
  "/users",
  [
    body("name").isString().notEmpty(),
    body("email").isEmail()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const newUser = {
      id: id++,
      name: req.body.name,
      email: req.body.email
    };

    users.push(newUser);
    res.status(201).json(newUser);
  }
);

// READ single user
app.get("/users/:id", (req, res) => {
  const user = users.find(u => u.id == req.params.id);
  if (!user) return res.status(404).json({ msg: "User not found" });

  res.json(user);
});

// UPDATE user
app.put(
  "/users/:id",
  [
    body("name").optional().isString(),
    body("email").optional().isEmail()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const user = users.find(u => u.id == req.params.id);
    if (!user) return res.status(404).json({ msg: "User not found" });

    if (req.body.name) user.name = req.body.name;
    if (req.body.email) user.email = req.body.email;

    res.json(user);
  }
);

// DELETE user
app.delete("/users/:id", (req, res) => {
  const index = users.findIndex(u => u.id == req.params.id);
  if (index === -1) return res.status(404).json({ msg: "User not found" });

  users.splice(index, 1);
  res.json({ msg: "User deleted" });
});

// TOTAL stats
app.get("/stats", (req, res) => {
  res.json({
    totalUsers: users.length,
    lastId: id - 1
  });
});

// READ all users (filter + sort + paginate)
app.get("/users", (req, res) => {
  const { search, sort, page = 1, limit = 5 } = req.query;
  let data = [...users];

  // Filtering
  if (search) {
    data = data.filter(
      u =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
    );
  }

  // Sorting
  if (sort === "name") {
    data.sort((a, b) => a.name.localeCompare(b.name));
  }

  // Pagination
  const start = (page - 1) * Number(limit);
  const end = start + Number(limit);
  const paginated = data.slice(start, end);

  res.json({
    total: data.length,
    page: Number(page),
    limit: Number(limit),
    data: paginated
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ msg: "Route not found" });
});

// ERROR handler
app.use((err, req, res, next) => {
  console.error("ERROR:", err);
  res.status(500).json({ msg: "Internal server error" });
});

// ---------- START ----------
app.listen(3000, () => {
  console.log("CRUD API running on http://localhost:3000");
});
