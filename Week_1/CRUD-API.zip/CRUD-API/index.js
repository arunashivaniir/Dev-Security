let users = [];
let id = 1;

const express = require("express");
const { body, validationResult } = require("express-validator");
const app = express();

app.use(express.json());

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url} - ${new Date().toISOString()}`);
  next();
});

app.post(
  "/users",
  [
    body("name").isString().notEmpty(),
    body("email").isEmail()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const newUser = {
      id: id++,
      name: req.body.name,
      email: req.body.email
    };

    users.push(newUser);
    res.status(201).json(newUser);
  }
);

app.listen(3000, () => {
  console.log("CRUD API running on http://localhost:3000");
});

app.get("/users/:id", (req, res) => {
  const user = users.find(u => u.id == req.params.id);
  if (!user) {
    return res.status(404).json({ msg: "User not found" });
  }
  res.json(user);
});

app.put(
  "/users/:id",
  [
    body("name").optional().isString(),
    body("email").optional().isEmail()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const user = users.find(u => u.id == req.params.id);
    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }

    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;

    res.json(user);
  }
);

app.delete("/users/:id", (req, res) => {
  const userIndex = users.findIndex(u => u.id == req.params.id);
  if (userIndex === -1) {
    return res.status(404).json({ msg: "User not found" });
  }

  users.splice(userIndex, 1);
  res.json({ msg: "User deleted" });
});

app.get("/stats", (req, res) => {
  res.json({
    totalUsers: users.length,
    lastId: id - 1
  });
});



app.get("/users", (req, res) => {
  const { search } = req.query;

  if (search) {
    const filtered = users.filter(u =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    );

    return res.json(filtered);
  }

  res.json(users);
});

app.get("/users", (req, res) => {
  const { search, page = 1, limit = 5 } = req.query;

  let data = [...users];

  // Filtering
  if (search) {
    data = data.filter(u =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    );
  }

  // Pagination
  const start = (page - 1) * limit;
  const end = start + Number(limit);

  const paginated = data.slice(start, end);

  res.json({
    total: data.length,
    page: Number(page),
    limit: Number(limit),
    data: paginated
  });
  
  if (req.query.sort === "name") {
  data.sort((a, b) => a.name.localeCompare(b.name));
}


});


app.use((req, res) => {
  res.status(404).json({ msg: "Route not found" });
});

app.use((err, req, res, next) => {
  console.error("ERROR:", err.message);
  res.status(500).json({ msg: "Internal server error" });
});


